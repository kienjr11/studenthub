/* JavaScript thuần, không dùng inline script nên tương thích Content-Security-Policy. */
(function () {
    'use strict';

    var csrf = document.querySelector('meta[name="csrf-token"]');
    // Dùng cho các request Fetch thay đổi dữ liệu (POST): gửi kèm header X-CSRF-Token.
    window.csrfHeaders = function (extra) {
        return Object.assign({ 'X-CSRF-Token': csrf ? csrf.content : '' }, extra || {});
    };

    // Hộp xác nhận cho form có data-confirm
    document.addEventListener('submit', function (ev) {
        var msg = ev.target.getAttribute && ev.target.getAttribute('data-confirm');
        if (msg && !window.confirm(msg)) { ev.preventDefault(); }
    });

    // Hiện/ẩn mật khẩu
    document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.querySelector(btn.getAttribute('data-toggle-password'));
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Ẩn' : 'Hiện';
        });
    });

    // Trang đăng ký: chỉ hiện ô "Đơn vị" khi chọn vai trò giảng viên
    var deptGroup = document.getElementById('dept-group');
    var roleInputs = document.querySelectorAll('input[name="role"]');
    function syncDept() {
        if (!deptGroup) { return; }
        var checked = document.querySelector('input[name="role"]:checked');
        deptGroup.classList.toggle('d-none', !checked || checked.value !== 'giang_vien');
    }
    roleInputs.forEach(function (r) { r.addEventListener('change', syncDept); });
    syncDept();

    // Trang đăng ký: kiểm tra email đã tồn tại chưa bằng Fetch API + endpoint JSON (có debounce)
    var emailInput = document.querySelector('[data-check-email]');
    var feedback = document.getElementById('email-feedback');
    if (emailInput && feedback) {
        var timer = null;
        var lastController = null;
        emailInput.addEventListener('input', function () {
            clearTimeout(timer);
            feedback.textContent = '';
            feedback.className = 'form-text';
            var value = emailInput.value.trim();
            if (value.length < 5 || value.indexOf('@') === -1) { return; }
            timer = setTimeout(function () {
                if (lastController) { lastController.abort(); }
                lastController = new AbortController();
                var url = emailInput.getAttribute('data-check-email');
                url += (url.indexOf('?') === -1 ? '?' : '&') + 'email=' + encodeURIComponent(value);
                fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin', signal: lastController.signal })
                    .then(function (res) { return res.json(); })
                    .then(function (data) {
                        feedback.textContent = data.message || '';
                        feedback.className = 'form-text ' + (data.available === true ? 'text-success' : data.available === false ? 'text-danger' : 'text-muted');
                    })
                    .catch(function (err) { if (err.name !== 'AbortError') { feedback.textContent = ''; } });
            }, 400);
        });
    }
})();
