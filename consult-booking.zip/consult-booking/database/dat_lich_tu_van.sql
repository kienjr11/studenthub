-- =====================================================================
-- ConsultBook - Hệ thống đặt lịch tư vấn / hẹn gặp giảng viên
-- Chạy: mysql -u root -p < database/schema.sql   (hoặc Import trong phpMyAdmin / HeidiSQL)
-- Tên bảng, tên cột và giá trị ENUM hoàn toàn bằng tiếng Việt không dấu.
-- Quy ước: khóa chính của bảng X tên là ma_x; khóa ngoại trỏ tới X cũng tên ma_x.
-- File này XÓA và tạo lại các bảng -> chỉ dùng cho môi trường dev/demo.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS dat_lich_tu_van CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dat_lich_tu_van;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Dọn sạch các bảng cũ (nếu có)
DROP TABLE IF EXISTS ho_so_giang_vien;
DROP TABLE IF EXISTS feedback, appointments, slots, lecturer_specialties, users, specialties, departments;
DROP TABLE IF EXISTS phan_hoi, cuoc_hen, khung_gio, giang_vien_chuyen_mon, nguoi_dung, chuyen_mon, don_vi;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- MODULE XÁC THỰC + QUẢN TRỊ: don_vi, chuyen_mon, nguoi_dung, giang_vien_chuyen_mon
-- ---------------------------------------------------------------------
CREATE TABLE don_vi (
    ma_don_vi    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ten_don_vi  VARCHAR(100) NOT NULL,
    mo_ta        VARCHAR(255) NULL,
    ngay_tao     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_don_vi_ten (ten_don_vi)
) ENGINE=InnoDB;

CREATE TABLE chuyen_mon (
    ma_chuyen_mon   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ten_chuyen_mon VARCHAR(100) NOT NULL,
    mo_ta          VARCHAR(255) NULL,
    ngay_tao       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_chuyen_mon_ten (ten_chuyen_mon)
) ENGINE=InnoDB;

CREATE TABLE nguoi_dung (
    ma_nguoi_dung        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ho_ten               VARCHAR(100) NOT NULL,
    email                VARCHAR(190) NOT NULL,
    mat_khau_bam         VARCHAR(255) NOT NULL,                                   -- chuỗi băm password_hash(), không lưu mật khẩu gốc
    vai_tro              ENUM('sinh_vien','giang_vien','quan_tri') NOT NULL DEFAULT 'sinh_vien',
    trang_thai           ENUM('hoat_dong','cho_duyet','da_khoa')  NOT NULL DEFAULT 'hoat_dong',
    ma_don_vi            INT UNSIGNED NULL,                                       -- chỉ giảng viên thuộc đơn vị
    so_lan_dang_nhap_sai TINYINT UNSIGNED NOT NULL DEFAULT 0,
    khoa_den             DATETIME NULL,                                           -- khóa tạm do đăng nhập sai nhiều lần
    dang_nhap_lan_cuoi   DATETIME NULL,
    ngay_tao             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_nguoi_dung_email (email),
    KEY idx_nguoi_dung_vai_tro_trang_thai (vai_tro, trang_thai),
    CONSTRAINT fk_nguoi_dung_don_vi FOREIGN KEY (ma_don_vi) REFERENCES don_vi(ma_don_vi)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE giang_vien_chuyen_mon (
    ma_giang_vien  INT UNSIGNED NOT NULL,                                         -- trỏ tới nguoi_dung (vai trò giang_vien)
    ma_chuyen_mon  INT UNSIGNED NOT NULL,
    PRIMARY KEY (ma_giang_vien, ma_chuyen_mon),
    CONSTRAINT fk_gvcm_giang_vien FOREIGN KEY (ma_giang_vien) REFERENCES nguoi_dung(ma_nguoi_dung) ON DELETE CASCADE,
    CONSTRAINT fk_gvcm_chuyen_mon FOREIGN KEY (ma_chuyen_mon) REFERENCES chuyen_mon(ma_chuyen_mon) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- MODULE HỒ SƠ & CHUYÊN MÔN: ho_so_giang_vien (quan hệ 1-1 với nguoi_dung có vai trò giang_vien)
-- Họ tên và đơn vị vẫn nằm ở nguoi_dung; bảng này chỉ chứa thông tin riêng của giảng viên.
-- Lĩnh vực tư vấn dùng lại bảng giang_vien_chuyen_mon (quan hệ n-n) đã có.
-- ---------------------------------------------------------------------
CREATE TABLE ho_so_giang_vien (
    ma_giang_vien  INT UNSIGNED NOT NULL PRIMARY KEY,
    hoc_ham        ENUM('giao_su','pho_giao_su') NULL,
    hoc_vi         ENUM('cu_nhan','ky_su','thac_si','tien_si') NULL,
    so_dien_thoai  VARCHAR(20)  NULL,
    phong_lam_viec VARCHAR(100) NULL,
    gioi_thieu     VARCHAR(1000) NULL,
    ngay_cap_nhat  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ho_so_giang_vien FOREIGN KEY (ma_giang_vien) REFERENCES nguoi_dung(ma_nguoi_dung) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- MODULE KHUNG GIỜ, CUỘC HẸN VÀ PHẢN HỒI
-- ---------------------------------------------------------------------
CREATE TABLE khung_gio (
    ma_khung_gio  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ma_giang_vien INT UNSIGNED NOT NULL,
    bat_dau       DATETIME NOT NULL,
    ket_thuc      DATETIME NOT NULL,
    dia_diem      VARCHAR(150) NULL,
    ngay_tao      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_khung_gio_giang_vien_bat_dau (ma_giang_vien, bat_dau),
    CONSTRAINT fk_khung_gio_giang_vien FOREIGN KEY (ma_giang_vien) REFERENCES nguoi_dung(ma_nguoi_dung) ON DELETE RESTRICT,
    CONSTRAINT chk_khung_gio_thoi_gian CHECK (ket_thuc > bat_dau)
) ENGINE=InnoDB;

-- Quy tắc "một khung giờ chỉ có tối đa một cuộc hẹn đang hiệu lực" ép trực tiếp ở CSDL:
-- Cột khung_gio_hieu_luc chỉ nhận giá trị khi cuộc hẹn ở trạng thái hiệu lực (cho_duyet, da_duyet, hoan_thanh).
-- Khóa UNIQUE chặn 2 người đăng ký cùng giữ một khung giờ.
CREATE TABLE cuoc_hen (
    ma_cuoc_hen        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ma_khung_gio       INT UNSIGNED NOT NULL,
    ma_sinh_vien       INT UNSIGNED NOT NULL,                                     -- trỏ tới nguoi_dung (vai trò sinh_vien)
    chu_de             VARCHAR(255) NOT NULL,
    trang_thai         ENUM('cho_duyet','da_duyet','tu_choi','da_huy','hoan_thanh') NOT NULL DEFAULT 'cho_duyet',
    ghi_chu_giang_vien TEXT NULL,
    khung_gio_hieu_luc INT UNSIGNED GENERATED ALWAYS AS
                       (IF(trang_thai IN ('cho_duyet','da_duyet','hoan_thanh'), ma_khung_gio, NULL)) STORED,
    ngay_tao           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_mot_cuoc_hen_hieu_luc_moi_khung_gio (khung_gio_hieu_luc),
    KEY idx_cuoc_hen_sinh_vien (ma_sinh_vien, trang_thai),
    CONSTRAINT fk_cuoc_hen_khung_gio FOREIGN KEY (ma_khung_gio) REFERENCES khung_gio(ma_khung_gio) ON DELETE RESTRICT,
    CONSTRAINT fk_cuoc_hen_sinh_vien FOREIGN KEY (ma_sinh_vien) REFERENCES nguoi_dung(ma_nguoi_dung) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE phan_hoi (
    ma_phan_hoi   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ma_cuoc_hen   INT UNSIGNED NOT NULL,
    diem_danh_gia TINYINT UNSIGNED NOT NULL,
    nhan_xet      VARCHAR(500) NULL,
    ngay_tao      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_phan_hoi_cuoc_hen (ma_cuoc_hen),
    CONSTRAINT fk_phan_hoi_cuoc_hen FOREIGN KEY (ma_cuoc_hen) REFERENCES cuoc_hen(ma_cuoc_hen) ON DELETE CASCADE,
    CONSTRAINT chk_phan_hoi_diem CHECK (diem_danh_gia BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- DỮ LIỆU MẪU (mật khẩu chung của mọi tài khoản demo: Demo@12345)
-- ---------------------------------------------------------------------
INSERT INTO don_vi (ten_don_vi, mo_ta) VALUES
 ('Khoa Công nghệ thông tin', 'Lập trình, mạng, dữ liệu, trí tuệ nhân tạo'),
 ('Khoa Kinh tế', 'Quản trị, marketing, khởi nghiệp'),
 ('Khoa Khoa học cơ bản', 'Toán, vật lý, kỹ năng nền tảng'),
 ('Phòng Công tác sinh viên', 'Hỗ trợ học vụ, học bổng, định hướng nghề nghiệp');

INSERT INTO chuyen_mon (ten_chuyen_mon, mo_ta) VALUES
 ('Lập trình Web', 'PHP, JavaScript, kiến trúc MVC'),
 ('Cơ sở dữ liệu', 'Thiết kế ERD, SQL, tối ưu truy vấn'),
 ('Trí tuệ nhân tạo', 'Học máy, xử lý dữ liệu'),
 ('Toán ứng dụng', 'Phương trình vi phân, mô hình hóa'),
 ('Khởi nghiệp', 'Kế hoạch kinh doanh, gọi vốn'),
 ('Hướng nghiệp', 'CV, phỏng vấn, lộ trình nghề nghiệp');

INSERT INTO nguoi_dung (ho_ten, email, mat_khau_bam, vai_tro, trang_thai, ma_don_vi) VALUES
 ('Quản trị hệ thống',  'admin@demo.test',      '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'quan_tri',   'hoat_dong', NULL),
 ('Nguyễn Văn Minh',    'gv.minh@demo.test',    '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'giang_vien', 'hoat_dong', 1),
 ('Trần Thu Hà',        'gv.ha@demo.test',      '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'giang_vien', 'hoat_dong', 2),
 ('Lê Quang Huy',       'gv.huy@demo.test',     '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'giang_vien', 'cho_duyet', 3),
 ('Phạm Thị An',        'sv.an@demo.test',      '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'sinh_vien',  'hoat_dong', NULL),
 ('Hoàng Gia Bảo',      'sv.bao@demo.test',     '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'sinh_vien',  'hoat_dong', NULL),
 ('Đỗ Minh Khôi',       'sv.khoi@demo.test',    '$2y$10$1IgX5hYLu/gNcArsS9szWu/XI.VGmsJBIY7wtLJ6C9cVo5b4.1NRK', 'sinh_vien',  'da_khoa',   NULL);

INSERT INTO giang_vien_chuyen_mon (ma_giang_vien, ma_chuyen_mon) VALUES (2, 1), (2, 2), (3, 5), (3, 6);

INSERT INTO ho_so_giang_vien (ma_giang_vien, hoc_ham, hoc_vi, so_dien_thoai, phong_lam_viec, gioi_thieu) VALUES
 (2, NULL, 'tien_si', '0901234567', 'P.305 – Nhà A', 'Giảng dạy lập trình web và cơ sở dữ liệu; sẵn sàng tư vấn đồ án và định hướng nghề nghiệp lập trình viên.'),
 (3, 'pho_giao_su', 'tien_si', NULL, 'P.210 – Nhà B', 'Tư vấn khởi nghiệp, xây dựng kế hoạch kinh doanh và kỹ năng xin việc.');